;(function() {
  'use strict';

  angular
    .module('templates', []);

})();
