Pace.options.ajax.trackMethods = [
  'GET',
  'POST',
  'PUT',
  'DELETE'
];
