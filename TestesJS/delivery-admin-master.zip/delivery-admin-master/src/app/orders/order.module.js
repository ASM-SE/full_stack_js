;(function() {
  'use strict';

  angular
  .module('app.orders', []);
}());
